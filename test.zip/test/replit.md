# TeeDesign Studio - Custom T-Shirt E-commerce Platform

## Overview

TeeDesign Studio is a full-stack e-commerce application that allows customers to browse and purchase T-shirts while offering a built-in design studio for creating custom designs. The platform includes both customer-facing features and an admin panel for managing products, orders, and inventory. The application features a React frontend with TypeScript, a Node.js/Express backend, and PostgreSQL database with session-based authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for fast development and building
- **Routing**: Wouter for client-side routing with protected routes for authenticated users
- **State Management**: TanStack React Query for server state management and caching
- **UI Framework**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Design Canvas**: HTML Canvas API implementation for custom T-shirt design functionality

### Backend Architecture
- **Runtime**: Node.js with Express.js framework and ES modules
- **Language**: TypeScript with strict type checking and path aliasing
- **Authentication**: Passport.js with local strategy using session-based authentication
- **Session Storage**: In-memory session store for development (configurable for production)
- **Password Security**: Node.js crypto module with scrypt for secure password hashing
- **API Design**: RESTful endpoints with standardized error handling and response formatting

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Comprehensive relational schema including:
  - Users with role-based access (customer/admin)
  - Products with categories, colors, sizes, and stock management
  - Custom designs with JSON storage for canvas data
  - Shopping cart and wishlist functionality
  - Orders with detailed item tracking and status management
- **Connection**: PostgreSQL connection pooling with environment-based configuration
- **Migrations**: Drizzle Kit for database schema management and migrations

### Authentication and Authorization
- **Strategy**: Session-based authentication with Passport.js local strategy
- **Security**: Scrypt-based password hashing with salt for secure storage
- **Session Management**: Express session middleware with configurable storage
- **Role-based Access**: Admin and customer roles with protected routes and API endpoints
- **Route Protection**: Custom protected route components for authenticated access

## External Dependencies

### Core Framework Dependencies
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect for database operations
- **express**: Web application framework for Node.js backend
- **passport**: Authentication middleware with local strategy support
- **react**: Frontend framework with hooks and context for state management
- **@tanstack/react-query**: Server state management and caching library

### UI and Styling
- **@radix-ui/react-***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework with custom configuration
- **class-variance-authority**: Utility for creating type-safe component variants
- **clsx**: Utility for conditional className composition

### Development and Build Tools
- **vite**: Fast build tool and development server with TypeScript support
- **tsx**: TypeScript execution for development server
- **esbuild**: Fast bundling for production builds
- **@types/node**: TypeScript definitions for Node.js APIs

### Database and Session Management
- **pg**: PostgreSQL client for Node.js with connection pooling
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **express-session**: Session middleware for Express applications

### Form Handling and Validation
- **react-hook-form**: Performant forms with minimal re-renders
- **@hookform/resolvers**: Validation resolvers for React Hook Form
- **zod**: TypeScript-first schema validation with runtime checking
- **drizzle-zod**: Integration between Drizzle ORM and Zod validation